# 우당탕탕 사자성어 탐험대 — GitHub Pages 버전

이 버전은 브라우저 TTS를 사용하지 않습니다. GitHub Actions가 ElevenLabs API로 **실제 MP3 파일을 생성**하고, GitHub Pages는 완성된 MP3를 일반 `<audio>`로 재생합니다.

## 1. GitHub 저장소 만들기

새 저장소를 만든 뒤 이 ZIP의 내용을 저장소 루트에 그대로 업로드합니다. 기본 브랜치는 `main`을 사용하세요.

## 2. ElevenLabs Voice ID 확인

ElevenLabs에서 사용할 목소리의 Voice ID를 준비합니다.

최소한 `NARRATOR` 1개만 있어도 됩니다. 준이/하나/사자봇 Voice ID를 따로 설정하지 않으면 내레이션 목소리를 같이 사용합니다.

## 3. GitHub Secrets 등록

저장소 → **Settings → Secrets and variables → Actions → New repository secret** 에서 아래를 등록합니다.

필수:
- `ELEVENLABS_API_KEY`
- `ELEVENLABS_VOICE_NARRATOR`

선택:
- `ELEVENLABS_VOICE_JUN`
- `ELEVENLABS_VOICE_HANA`
- `ELEVENLABS_VOICE_SAJABOT`

API Key는 절대 HTML이나 JavaScript 파일에 직접 넣지 마세요.

## 4. Pages 설정

저장소 → **Settings → Pages → Build and deployment → Source** 를 **GitHub Actions**로 설정합니다.

## 5. 실행

**Actions → Build audiobook and deploy Pages → Run workflow** 를 누릅니다.

작업이 끝나면 Settings → Pages에 공개 주소가 표시됩니다.

## 현재 수록

1. 작심삼일
2. 우왕좌왕
3. 일석이조

## 구조

- `public/` : 실제 GitHub Pages 사이트
- `public/episodes.js` : 이야기 대본
- `scripts/generate-audio.mjs` : ElevenLabs MP3 생성기
- `.github/workflows/pages.yml` : 자동 MP3 생성 + Pages 배포

## 주의

GitHub Actions를 다시 실행하면 MP3를 다시 생성하므로 ElevenLabs 크레딧이 다시 사용됩니다. 대본이 확정된 뒤 실행하는 것을 권장합니다.
