import { episodes } from './episodes.js';

const $ = (id) => document.getElementById(id);
const audio = $('audio');
let currentEpisode = 0;
let currentLine = 0;
let playing = false;
let manifest = null;

function esc(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}

async function loadManifest(){
  try{
    const r = await fetch('./audio/manifest.json', {cache:'no-store'});
    if(!r.ok) throw new Error('manifest missing');
    manifest = await r.json();
    $('status').textContent = 'MP3 준비 완료';
  }catch(e){
    $('status').textContent = 'MP3가 아직 생성되지 않았습니다';
    $('caption').innerHTML = 'GitHub Actions에서 ElevenLabs MP3 생성이 완료되면 바로 들을 수 있습니다.';
  }
}

function renderList(){
  $('episodeCount').textContent = `${episodes.length}편`;
  $('episodeList').innerHTML = episodes.map((e,i)=>`<button class="episode-card ${i===currentEpisode?'active':''}" data-i="${i}"><span class="n">제${e.no}화</span><strong>${esc(e.title)}</strong><span>${esc(e.meaning)}</span></button>`).join('');
  document.querySelectorAll('.episode-card').forEach(b=>b.onclick=()=>selectEpisode(Number(b.dataset.i)));
}

function renderEpisode(){
  const e=episodes[currentEpisode];
  $('episodeNo').textContent=`제${e.no}화`;
  $('episodeTitle').textContent=e.title;
  $('episodeMeaning').textContent=e.meaning;
  $('hanja').textContent=e.hanja;
  $('example').textContent=e.example;
  $('quiz').textContent='🧠 퀴즈: '+e.quiz;
  currentLine=Math.min(currentLine,e.lines.length-1);
  renderLine();
  renderList();
}

function renderLine(){
  const e=episodes[currentEpisode];
  const line=e.lines[currentLine];
  $('caption').textContent=line ? line[1] : '끝';
  $('lineInfo').textContent=`${currentLine+1} / ${e.lines.length}`;
  $('progressBar').style.width=`${((currentLine+1)/e.lines.length)*100}%`;
}

function getSrc(){
  const e=episodes[currentEpisode];
  const entry=manifest?.episodes?.[e.id]?.[currentLine];
  return entry ? `./audio/${entry.file}` : null;
}

async function playCurrent(){
  if(!manifest){$('status').textContent='MP3가 없습니다';return;}
  const src=getSrc();
  if(!src){$('status').textContent='이 문장의 MP3를 찾을 수 없습니다';return;}
  audio.src=src;
  audio.playbackRate=Number($('speedSelect').value);
  renderLine();
  try{await audio.play(); playing=true; $('playBtn').textContent='⏸'; $('status').textContent='재생 중';}
  catch(e){$('status').textContent='재생 오류: '+e.message;}
}

function pause(){audio.pause();playing=false;$('playBtn').textContent='▶';$('status').textContent='일시정지';}
function selectEpisode(i){pause(); currentEpisode=i; currentLine=0; renderEpisode();}

$('playBtn').onclick=()=>{ if(!playing) playCurrent(); else pause(); };
$('restartBtn').onclick=()=>{pause();currentLine=0;renderLine();playCurrent();};
$('prevBtn').onclick=()=>{pause();currentLine=Math.max(0,currentLine-1);renderLine();playCurrent();};
$('nextBtn').onclick=()=>{pause();const e=episodes[currentEpisode];currentLine=Math.min(e.lines.length-1,currentLine+1);renderLine();playCurrent();};
$('speedSelect').onchange=()=>{audio.playbackRate=Number($('speedSelect').value);};
audio.onended=()=>{
  const e=episodes[currentEpisode];
  if(currentLine<e.lines.length-1){currentLine++;playCurrent();}
  else {playing=false;$('playBtn').textContent='▶';$('status').textContent='에피소드 완료 🎉';}
};
audio.onerror=()=>{$('status').textContent='오디오 파일을 불러오지 못했습니다';playing=false;$('playBtn').textContent='▶';};

await loadManifest();
renderEpisode();
