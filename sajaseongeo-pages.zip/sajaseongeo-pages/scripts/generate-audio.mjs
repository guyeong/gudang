import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const publicDir = path.join(root, 'public');
const audioDir = path.join(publicDir, 'audio');
await fs.mkdir(audioDir, {recursive:true});

const apiKey = process.env.ELEVENLABS_API_KEY;
if (!apiKey) throw new Error('ELEVENLABS_API_KEY secret is missing.');

const narrator = process.env.ELEVENLABS_VOICE_NARRATOR || process.env.ELEVENLABS_VOICE_ID;
if (!narrator) throw new Error('Set ELEVENLABS_VOICE_NARRATOR or ELEVENLABS_VOICE_ID.');
const voices = {
  narrator,
  jun: process.env.ELEVENLABS_VOICE_JUN || narrator,
  hana: process.env.ELEVENLABS_VOICE_HANA || narrator,
  sajabot: process.env.ELEVENLABS_VOICE_SAJABOT || narrator,
};

const mod = await import(pathToFileURL(path.join(publicDir,'episodes.js')).href);
const episodes = mod.episodes;
const manifest = {generatedAt:new Date().toISOString(), model:'eleven_multilingual_v2', episodes:{}};

async function tts(text, voiceId){
  const url = `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}?output_format=mp3_44100_128`;
  const res = await fetch(url, {
    method:'POST',
    headers:{'Content-Type':'application/json','xi-api-key':apiKey},
    body:JSON.stringify({
      text,
      model_id:'eleven_multilingual_v2',
      voice_settings:{stability:0.45, similarity_boost:0.78, style:0.28, use_speaker_boost:true}
    })
  });
  if(!res.ok){
    const body = await res.text();
    throw new Error(`ElevenLabs ${res.status}: ${body}`);
  }
  return Buffer.from(await res.arrayBuffer());
}

for(const ep of episodes){
  manifest.episodes[ep.id]=[];
  console.log(`Generating episode ${ep.no}: ${ep.title}`);
  for(let i=0;i<ep.lines.length;i++){
    const [speaker,text]=ep.lines[i];
    const file=`${ep.id}/${String(i+1).padStart(3,'0')}-${speaker}.mp3`;
    const target=path.join(audioDir,file);
    await fs.mkdir(path.dirname(target),{recursive:true});
    const buf=await tts(text,voices[speaker]||narrator);
    await fs.writeFile(target,buf);
    manifest.episodes[ep.id].push({speaker,text,file});
    console.log(`  ${i+1}/${ep.lines.length} ${speaker}`);
  }
}
await fs.writeFile(path.join(audioDir,'manifest.json'),JSON.stringify(manifest,null,2));
console.log('Audio generation complete.');
